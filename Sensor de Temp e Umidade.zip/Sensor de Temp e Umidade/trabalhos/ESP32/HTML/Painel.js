const barra_tmp = document.getElementById("barraTMP");
const barra_umd = document.getElementById("barraUMD");
const displayTMP = document.getElementById("TMP");
const displayUMD = document.getElementById("UMD");
const NAV_plantas = document.getElementById("nav");
const plantas_tela = document.getElementsByClassName("planta");
const display_infos = document.getElementById("infos_planta");
const titulo = document.querySelector("#Painel h2");
const titulo_italic = document.querySelector("#Painel i");
const fechar_grafs = document.getElementById("fecharbtn");
const graficos_div = document.getElementById("graficos");
const labels = [];
const temperaturaData = [];
const umidadeData = [];


//define a cor do grafico em função do percentual de preenchimento dele
function setCor(per, cor1, cor2){
    const r = Math.round(cor1[0] + (cor2[0] - cor1[0]) * per);
    const g = Math.round(cor1[1] + (cor2[1] - cor1[1]) * per);
    const b = Math.round(cor1[2] + (cor2[2] - cor1[2]) * per);
    return `rgb(${r}, ${g}, ${b})`;
}

//reenderiza o grafico da temperatura
function renderTMP( TMP, plantas, indice){
    const vermelho = [255,0,0];
    const verde_aceitavel = [24,179,3];
    const verde_ideal = [45, 236, 6];
    const azul = [0,217,255];
    
    let percentual = (TMP - plantas[indice].tmp_min) / (plantas[indice].tmp_max - plantas[indice].tmp_min);
    let angulo = percentual*180;
    let cor;
    
    if ( percentual <= 0.25){
        cor = setCor(percentual, azul, verde_aceitavel);
    } else if (percentual <= 0.5){
        cor = setCor(percentual, verde_aceitavel, verde_ideal);
    } else if (percentual <= 0.85){
        const p = 2*(percentual - 0.5);
        cor = setCor(percentual,verde_ideal, verde_aceitavel);
    } else {
        const p = 2*(percentual - 0.5);
        cor = setCor(percentual,verde_aceitavel, vermelho);
    }
    
    
    barra_tmp.style.background = "conic-gradient( "+cor+" "+angulo+"deg, white 0deg";
    displayTMP.style.color = cor;
    
    displayTMP.innerHTML = "Temperatura: "+TMP+"°C";
}

//reenderiza o grafico da umidade
function renderUMD( UMD, plantas, indice ){
    const vermelho = [255,0,0];
    const verde_aceitavel = [24,179,3];
    const verde_ideal = [45, 236, 6];
    const azul = [0,217,255];
    
    let percentual = (UMD - plantas[indice].umd_min) / (plantas[indice].umd_max - plantas[indice].umd_min);
    let angulo = percentual*180;
    let cor = "blue";
    
    barra_umd.style.background = "conic-gradient( "+cor+" "+angulo+"deg, white 0deg";
    displayUMD.style.color = cor;
    displayUMD.innerHTML = "Umidade: "+UMD+"%";
}


//reenderiza todas as plantas do banco de dados na barra NAV
//recebe o argumento plantasJSON, que nao e um json , mas o objeto que resulta dele
function render_plantas( plantasJSON ){
    console.log(plantasJSON);
    let count = -1;
    NAV_plantas.innerHTML += "<div id='cadastrar' class='planta'>"+
                                  "<div>+</div>"+
                                  "Cadastrar"+
                              "</div>";

    NAV_plantas.innerHTML += "<div id='grafs' class='planta'>" +
                                    "<div>&#x1F4C8;</div>"+
                                    "Gráficos"+
                                "</div>";

    let cadast = document.getElementById("cadast");
    plantasJSON.forEach((planta) => {
        count++;
        let figura;
        switch (planta.tipo){
            case "arvore":
                figura = "&#127795;";
                break;
            case "erva":
                figura = "&#127807;";
                break;
            case "flor":
                figura = "&#127803;";
                break;
            case "grao":
                figura = "&#127793;";
        }
        NAV_plantas.innerHTML += "<div id='"+count+"' class='planta'>"+
                                      "<div>"+figura+"</div>"+
                                      planta.nome+  
                                 "</div>";
    });
}

//reenderiza as informações da planta escolhida, como genero e epiteto
function render_infos_planta(plantas, indice){
    titulo.innerHTML = plantas[indice].nome;
    titulo_italic.innerHTML = plantas[indice].genero + " " + plantas[indice].epiteto;
    display_infos.innerHTML = "<p>-temperatura minima: "+plantas[indice].tmp_min+"°C</p>"+
                              "<p>-temperatura maxima: "+plantas[indice].tmp_max+"°C</p>"+
                              "<p>-umidade minima: "+plantas[indice].umd_min+"%</p>"+
                              "<p>-umidade maxima: "+plantas[indice].umd_max+"%</p>";
}

//mostra o input do cadastro na tela
function render_cadas(){
    cadast.classList.add("mostrado");
    console.log("clicado");
    
}

//mostra a tela de gráficos
function render_graficos(){
    graficos_div.classList.remove("inativo");
    graficos_div.classList.add("ativo");
}

//fechar janela de graficos
fechar_grafs.onclick = () => {
    graficos_div.classList.remove("ativo");
    graficos_div.classList.add("inativo");
}

//fluxo principal do programa da tela
let indice = 0;
renderTMP( tmp, plantas, indice);
renderUMD(umd, plantas, indice);
render_plantas( plantas );
render_infos_planta(plantas, indice);

//serve para adicionar os eventos para as divs .planta na tela
for( let i = 0 ; i < plantas_tela.length; i++){
    plantas_tela[i].onclick = () => {
        indice = i;
        renderTMP(tmp, plantas,indice);
        render_infos_planta(plantas, indice);
        renderUMD(umd, plantas, indice);
    };
    if (plantas_tela[i].id === "cadastrar"){
        plantas_tela[i].onclick = () => {render_cadas()};
    }
    if (plantas_tela[i].id === "grafs"){
        plantas_tela[i].onclick = () => {render_graficos()};
    }
}

setInterval( () => {
    fetch("http://"+window.location.hostname+"/tmp_e_umd", {
        method : "GET"
    }).then(r => {return r.json()}).then(r => {

        const agora = new Date();
        const horario = agora.toLocaleTimeString();

        labels.push(horario);
        temperaturaData.push(r.tmp);
        umidadeData.push(r.umd);

        if (labels.length > 1800) {
            labels.shift();
            temperaturaData.shift();
            umidadeData.shift();
        }

        grafico.update()

        renderTMP(r.tmp, plantas,indice);
        renderUMD(r.umd, plantas, indice);
    })
}, 2000 );


CREATE DATABASE IF NOT EXISTS Plantas;
USE Plantas;

CREATE TABLE Planta(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50),
    genero VARCHAR(50),
    epiteto VARCHAR(50),
    tmp_minima DOUBLE,
    tmp_maxima DOUBLE,
    tmp_ideal DOUBLE,
    umidade_ideal DOUBLE,
    umidade_minima DOUBLE,
    umidade_ideal DOUBLE,
    tipo VARCHAR(20)
);
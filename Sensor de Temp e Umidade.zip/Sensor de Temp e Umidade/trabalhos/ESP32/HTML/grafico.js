const canvas_grafico = document.getElementById("grafico");
const ctx = canvas_grafico.getContext("2d");

const grafico = new Chart(ctx, {
  type: 'line',
  data: {
    labels: labels,
    datasets: [
      {
        label: 'Temperatura (°C)',
        data: temperaturaData,
        borderColor: 'red', 
        backgroundColor: 'rgba(255, 0, 0, 0.1)',
        fill: true,
        tension: 0.3
      },
      {
        label: 'Umidade (%)',
        data: umidadeData,
        borderColor: 'blue', 
        backgroundColor: 'rgba(0, 0, 255, 0.1)',
        fill: true,
        tension: 0.3
      }
    ]
  },
  options: {
    scales: {
      x: {
        title: {
          display: true,
          text: 'Horário',
          color: 'white' 
        },
        grid: {
          color: '#A5D6A7'
        },
        ticks: {
          color: '#2E7D32'
        }
      },
      y: {
        beginAtZero: true,
        min: 0,
        max: 100,
        title: {
          display: true,
          text: 'Valor',
          color: 'white' 
        },
        grid: {
          color: '#A5D6A7'
        },
        ticks: {
          color: 'white'
        }
      }
    },
    plugins: {
      legend: {
        labels: {
          color: 'white' 
        }
      }
    }
  }
});

html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel | Controle</title>
    <link rel="stylesheet" href="Painel.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body{
            margin: 0px;
        }

        main{
            display: flex;
            height: 100vh;
            width: 100vw;
        }


        #Painel{
            width: 100%;
            padding: 50px 10px 0px 10px;
        }

        h3{
            margin-left:20%;
            font-family: "Arial";
        }

        #infos{
            display: flex;
            padding-left:10% ;
            gap: 20%;
        }

        #temperatura{
            text-align: center;
            font-family: "Arial";
        }

        #umidade{
            text-align: center;
            font-family: "Arial";
        }

        #barraTMP{
            height: 100px;
            width: 100px;
            border-radius: 50%;
            border: 5px solid white;
            background: conic-gradient(#3498db 5deg , white 0deg);
            transform: rotate(-90deg);
            display: flex;
            align-items: center;
            justify-content: center;
            
        }

        #barraUMD{
            color: rgb(0, 217, 255);
            height: 100px;
            width: 100px;
            border-radius: 50%;
            border: 5px solid white;
            background: conic-gradient(#3498db 5deg , white 0deg);
            transform: rotate(-90deg);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .circulo{
            width: 85px;
            height: 85px;
            border-radius: 50%;
            background-color: white;
        }

        #nav {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 90px;
            height: 100vh;
            background-color: rgb(24, 179, 3); 
            box-shadow: 5px 0px 30px rgba(0, 0, 0, 0.3);
            padding: 16px 0px 0px 0px;
            gap: 16px;
            overflow-y: auto;  
            scroll-behavior: smooth; 
        }


        #nav::-webkit-scrollbar {
            width: 6px; 
        }

        #nav::-webkit-scrollbar-track {
            background: rgb(24, 179, 3); 
            border-radius: 10px; 
        }

        #nav::-webkit-scrollbar-thumb {
            background-color: #27ae60; 
            border-radius: 10px; 
            border: 2px solid rgb(24, 179, 3); 
        }

        #nav::-webkit-scrollbar-thumb:hover {
            background-color: #2ecc71; 
        }



        .planta{
            width: calc(100% - 10px);
            height: 50px;
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 5px;
            font-family: "arial";
            font-size: 12px;
        }

        .planta:hover{
            background-color: rgb(22, 158, 4);
        }

        .planta div{
            display: flex;
            justify-content: center;
            align-items: center;
            width: 40px;
            height: 40px;
            background-color:rgb(122, 241, 106);
            border-radius: 50%;
        }

        #infos_planta{
            padding-left: 10% ;
        }

        h2{
            font-family: "Segoe Script", "Lucida Handwriting", cursive;
            font-size: 25px;
            color: rgb(7, 54, 1);
            margin-bottom: 0px;
            padding-left: 15%;
        }

        #Painel i{
            padding-left: 15%;
        }

        #infos_planta p{
            margin-bottom: 0px;
            padding-bottom: 0px;
        }

        .cadas{
            display: flex;
            position: fixed;
            flex-direction: column;
            background-color: #1a6e3d;
            color: white;
            width: 50%;
            max-width: 500px;
            border-radius: 5px;
            padding: 10px;
            gap: 10px;
            font-family: 'Arial';
            transition: 0.3s ease;
            bottom: 15%;
        }

        .mostrado{
            display: flex;
            pointer-events: auto;
        }

        .cadas input{
            display: flex;
            border-radius: 5px;
            height: 20px;
            padding: 3px;
            border: none;
        }

        #tipos{
            display: flex;
            flex-direction: row;
            justify-content: space-around;
        }

        #btn{
            display: flex;
            justify-content: end;
        }

        #botao{
            width: 100px;
            height: 20px;
            cursor: pointer;
            color: rgb(221, 249, 194);
            background-color: rgb(34, 172, 15);
            transition: 0.3s ease;
        }

        #botao:hover{
            background-color: rgb(33, 192, 12);
        }

        #fecharcadas{
            width: 20px;
            height: 20px;
            cursor: pointer;
            color: rgb(221, 249, 194);
            background-color: rgb(34, 172, 15);
            border-radius: 3px;
            border: none;
            transition: 0.3s ease;
        }

        #fecharcadas:hover{
            background-color: rgb(33, 192, 12);
        }

        #fecharcadas_div{
            display: flex;
            justify-content: end;
            padding: 0px 10px 0px 0px;
        }

        #graficos{
            position: fixed;
            z-index: 10;
            left: 30%;
            width: 50%;
            height: 50%;
            background-color: #1a6e3d;
            border-radius: 5px;
            border: none;
            transition: 0.3s ease;
            
        }

        #fechar{
            display: flex;
            justify-content: end;
            padding: 10px 10px 0px 10px;
        }

        #fecharbtn{
            width: 20px;
            height: 20px;
            cursor: pointer;
            color: rgb(221, 249, 194);
            background-color: rgb(34, 172, 15);
            border-radius: 3px;
            border: none;
            transition: 0.3s ease;
        }

        #fecharbtn:hover{
            background-color: rgb(33, 192, 12);
        }

        .inativo{
            opacity: 0;
            pointer-events: none;
        }

        .ativo {
            opacity: 1;
            pointer-events: auto;
        }

        #cooler_div {
            display: flex;
            justify-content: end;
            width: 20%;
            margin-left: 30%;
        }

        #cooler {
            width: 20%;
            padding: 5px 3px;
            cursor: pointer;
            background-color: rgb(232, 24, 24);
            color: white;
            border-radius: 5px;
            border: none;
            margin-left: 10%;
        }

    </style>
</head>
<body>
    <main>
        <div id="nav">
            
        </div>
        <div id="Painel">
            <div class="inativo" id="graficos">
                <div id="fechar">
                    <input type="button" id="fecharbtn" value="X">
                </div>
                <canvas id="grafico"></canvas>
            </div>
            <h2></h2>
            <i></i>
            <p style="color: white;">.</p>
            <div id="infos">
                <div id="temperatura">
                    <div id="barraTMP"><div class="circulo"></div></div>
                    <p id="TMP">Temperatura: </p>
                </div>
                <div id="umidade">
                    <div id="barraUMD"><div class="circulo"></div></div>
                    <p id="UMD">Umidade: </p>
                </div>
                <div class="cadas inativo" id="cadast">
                    <div id="fecharcadas_div" >
                        <input type="button" id="fecharcadas" onclick="fechar_cadas()" value="X">
                    </div>
                    <p>Nova planta</p>
                    <input type="text" placeholder="Nome" id="nome">
                    <input type="text" placeholder="Temperatura máxima" id="tmpmaxim">
                    <input type="text" placeholder="Temperatura mínima" id="tmpminim">
                    <input type="text" placeholder="Umidade_maxima" id="umdmaxim">
                    <input type="text" placeholder="Umidade_minima" id="umdminim">
                    <input type="text" placeholder="Gênero" id="genero">
                    <input type="text" placeholder="Epiteto" id="epiteto">
                    <div id="tipos">
                        <input type="radio" name="tipo" id="1" value="arvore"><label for="1">Arvore</label>
                        <input type="radio" name="tipo" id="2" value="erva"><label for="2">Erva</label>
                        <input type="radio" name="tipo" id="3" value="flor"><label for="3">Flor</label>
                        <input type="radio" name="tipo" id="4" value="grão"><label for="4">Grão</label>
                    </div>
                    <div id="btn"><input type="button" id="botao" value="Cadastrar"></div>
                </div>
            </div>
            <div id="infos_planta">
            </div>
            <div id=\cooler_div>
                <input type=button value="ligar cooler" onclick="controlar_cooler()" id=cooler>
            </div>
        </div>
    </main>
</body>
    <script>
        let tmp = 1;
        let umd = 1;

        let plantas = [{nome:"Samambaia",tmp_max:50,tmp_min:15,umd_max:60,umd_min:40,genero:"Nephrolepsis",epiteto:"exaltata", tipo:"erva"}];
        const labels = [];
        const temperaturaData = [];
        const umidadeData = [];
        const canvas_grafico = document.getElementById("grafico");
        const ctx = canvas_grafico.getContext("2d");

        const grafico = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
            {
                label: 'Temperatura (°C)',
                data: temperaturaData,
                borderColor: 'red', 
                backgroundColor: 'rgba(255, 0, 0, 0.1)',
                fill: true,
                tension: 0.3
            },
            {
                label: 'Umidade (%)',
                data: umidadeData,
                borderColor: 'blue', 
                backgroundColor: 'rgba(0, 0, 255, 0.1)',
                fill: true,
                tension: 0.3
            }
            ]
        },
        options: {
            scales: {
            x: {
                title: {
                display: true,
                text: 'Horário',
                color: 'white' 
                },
                grid: {
                color: '#A5D6A7'
                },
                ticks: {
                color: '#2E7D32'
                }
            },
            y: {
                beginAtZero: true,
                min: 0,
                max: 100,
                title: {
                display: true,
                text: 'Valor',
                color: 'white' 
                },
                grid: {
                color: '#A5D6A7'
                },
                ticks: {
                color: 'white'
                }
            }
            },
            plugins: {
            legend: {
                labels: {
                color: 'white' 
                }
            }
            }
        }
        });


        const barra_tmp = document.getElementById("barraTMP");
        const barra_umd = document.getElementById("barraUMD");
        const displayTMP = document.getElementById("TMP");
        const displayUMD = document.getElementById("UMD");
        const NAV_plantas = document.getElementById("nav");
        const plantas_tela = document.getElementsByClassName("planta");
        const display_infos = document.getElementById("infos_planta");
        const titulo = document.querySelector("#Painel h2");
        const titulo_italic = document.querySelector("#Painel i");
        const fechar_grafs = document.getElementById("fecharbtn");
        const graficos_div = document.getElementById("graficos");
        const botao = document.getElementById("botao");
        let url = "192.168.229.10";

        // NAO ESQUEÇA DE COLOCAR O WINDOW.HOSTNAME DEVOLTA !!!!!!!!!!!!!!!!!!!!!!!!!!

        botao.onclick = () => {
            let tmpmaxim = document.getElementById("tmpmaxim").value;
            let tmpminim = document.getElementById("tmpminim").value;
            let umdmaxim = document.getElementById("umdmaxim").value;
            let umdminim = document.getElementById("umdminim").value;
            let genero = document.getElementById("genero").value;
            let epiteto = document.getElementById("epiteto").value;

            const dados = new FormData();
            dados.append("tmpmaxim", tmpmaxim);
            dados.append("tmpminim", tmpminim);
            dados.append("umdmaxim", umdmaxim);
            dados.append("umdminim", umdminim);
            dados.append("genero", genero);
            dados.append("epiteto", epiteto);

            fetch("http://"+url+"/cadastrar_planta", {
                method : "POST",
                body : dados
            }).then(r => {
                return r.text();
            }).then(r => {
                console.log(r);
                console.log("req enviadad");
            })
         };

        function carregar_novas_plantas(){
            fetch("http://"+url+"/recuperar", {
                method : "GET"
            }).then( r => {
                return r.json();
            }).then(r => {
                plantas.push(r);

            });
        }

        //define a cor do grafico em função do percentual de preenchimento dele
        function setCor(per, cor1, cor2){
            const r = Math.round(cor1[0] + (cor2[0] - cor1[0]) * per);
            const g = Math.round(cor1[1] + (cor2[1] - cor1[1]) * per);
            const b = Math.round(cor1[2] + (cor2[2] - cor1[2]) * per);
            return `rgb(${r}, ${g}, ${b})`;
        }

        function controlar_cooler() {
        const cooler_btn = document.getElementById("cooler");
        const valor = cooler_btn.value;

        if (valor === "ligar cooler") {
            cooler_btn.style.backgroundColor = "rgb(95, 198, 245)";
            cooler_btn.value = "desligar cooler";
            fetch("http://"+url+"/ligar")
                .then(r => r.text())
                .then(texto => console.log("Resposta do servidor:", texto));
        } else {
            cooler_btn.style.backgroundColor = "rgb(232, 24, 24)";
            cooler_btn.value = "ligar cooler";
            fetch("http://"+url+"/desligar")
               .then(r => r.text())
                .then(texto => console.log("Resposta do servidor:", texto));
    }
}

        //reenderiza o grafico da temperatura
        function renderTMP( TMP, plantas, indice){
            const vermelho = [255,0,0];
            const verde_aceitavel = [24,179,3];
            const verde_ideal = [45, 236, 6];
            const azul = [0,217,255];
            
            let percentual = (TMP - plantas[indice].tmp_min) / (plantas[indice].tmp_max - plantas[indice].tmp_min);
            let angulo = percentual*180;
            let cor;
            
            if ( percentual <= 0.25){
                cor = setCor(percentual, azul, verde_aceitavel);
            } else if (percentual <= 0.5){
                cor = setCor(percentual, verde_aceitavel, verde_ideal);
            } else if (percentual <= 0.85){
                const p = 2*(percentual - 0.5);
                cor = setCor(percentual,verde_ideal, verde_aceitavel);
            } else {
                const p = 2*(percentual - 0.5);
                cor = setCor(percentual,verde_aceitavel, vermelho);
            }
            
            
            barra_tmp.style.background = "conic-gradient( "+cor+" "+angulo+"deg, white 0deg";
            displayTMP.style.color = cor;
            
            displayTMP.innerHTML = "Temperatura: "+TMP+"°C";
        }

        //reenderiza o grafico da umidade
        function renderUMD( UMD, plantas, indice ){
            const vermelho = [255,0,0];
            const verde_aceitavel = [24,179,3];
            const verde_ideal = [45, 236, 6];
            const azul = [0,217,255];
            
            let percentual = (UMD - plantas[indice].umd_min) / (plantas[indice].umd_max - plantas[indice].umd_min);
            let angulo = percentual*180;
            let cor = "blue";
            
            barra_umd.style.background = "conic-gradient( "+cor+" "+angulo+"deg, white 0deg";
            displayUMD.style.color = cor;
            displayUMD.innerHTML = "Umidade: "+UMD+"%";
        }


        //reenderiza todas as plantas do banco de dados na barra NAV
        //recebe o argumento plantasJSON, que nao e um json , mas o objeto que resulta dele
        function render_plantas( plantasJSON ){
            console.log(plantasJSON);
            let count = -1;
            NAV_plantas.innerHTML += "<div id='cadastrar' class='planta'>"+
                                        "<div>+</div>"+
                                        "Cadastrar"+
                                    "</div>";

            NAV_plantas.innerHTML += "<div id='grafs' class='planta'>" +
                                            "<div>&#x1F4C8;</div>"+
                                            "Gráficos"+
                                        "</div>";

            let cadast = document.getElementById("cadast");
            plantasJSON.forEach((planta) => {
                count++;
                let figura;
                switch (planta.tipo){
                    case "arvore":
                        figura = "&#127795;";
                        break;
                    case "erva":
                        figura = "&#127807;";
                        break;
                    case "flor":
                        figura = "&#127803;";
                        break;
                    case "grao":
                        figura = "&#127793;";
                }
                NAV_plantas.innerHTML += "<div id='"+count+"' class='planta'>"+
                                            "<div>"+figura+"</div>"+
                                            planta.nome+  
                                        "</div>";
            });
        }

        //reenderiza as informações da planta escolhida, como genero e epiteto
        function render_infos_planta(plantas, indice){
            titulo.innerHTML = plantas[indice].nome;
            titulo_italic.innerHTML = plantas[indice].genero + " " + plantas[indice].epiteto;
            display_infos.innerHTML = "<p>-temperatura minima: "+plantas[indice].tmp_min+"°C</p>"+
                                    "<p>-temperatura maxima: "+plantas[indice].tmp_max+"°C</p>"+
                                    "<p>-umidade minima: "+plantas[indice].umd_min+"%</p>"+
                                    "<p>-umidade maxima: "+plantas[indice].umd_max+"%</p>";
        }

        //mostra o input do cadastro na tela
        //mostra o input do cadastro na tela
        function render_cadas(){
            cadast.classList.remove("inativo");
            cadast.classList.add("ativo");
        }

        function fechar_cadas(){
            cadast.classList.remove("ativo");
            cadast.classList.add("inativo");
        }

        //mostra a tela de gráficos
        function render_graficos(){
            graficos_div.classList.remove("inativo");
            graficos_div.classList.add("ativo");
        }

        //fechar janela de graficos
        fechar_grafs.onclick = () => {
            graficos_div.classList.remove("ativo");
            graficos_div.classList.add("inativo");
        }

        //fluxo principal do programa da tela
        let indice = 0;
        renderTMP( tmp, plantas, indice);
        renderUMD(umd, plantas, indice);
        
        render_plantas( plantas );
        render_infos_planta(plantas, indice);

        //serve para adicionar os eventos para as divs .planta na tela
        for( let i = 0 ; i < plantas_tela.length; i++){
            plantas_tela[i].onclick = () => {
                indice = i;
                renderTMP(tmp, plantas,indice);
                render_infos_planta(plantas, indice);
                renderUMD(umd, plantas, indice);
            };
            if (plantas_tela[i].id === "cadastrar"){
                plantas_tela[i].onclick = () => {render_cadas()};
            }
            if (plantas_tela[i].id === "grafs"){
                plantas_tela[i].onclick = () => {render_graficos()};
            }
        }

        fetch("http://"+url+"/carregar_dados", {
            method : "GET"
        }).then(r => {return r.json()}).then(r => {
            temperaturaData.push(...r["temperaturas"]);
            umidadeData.push(...r["humidades"]);
            labels.push(...r["labels"]);
            console.log(r);
        });

        setInterval( () => {
            fetch("http://"+url+"/tmp_e_umd", {
                method : "GET"
            }).then(r => {return r.json()}).then(r => {

                const agora = new Date();
                const horario = agora.toLocaleTimeString();

                labels.push(horario);
                temperaturaData.push(r.tmp);
                umidadeData.push(r.umd);

                if (labels.length > 1800) {
                    labels.shift();
                    temperaturaData.shift();
                    umidadeData.shift();
                }

                grafico.update();

                renderTMP(r.tmp, plantas,indice);
                renderUMD(r.umd, plantas, indice);
            })
        }, 2000 );


    </script>
</html>
"""

# Quebra o conteúdo em linhas, escapa aspas duplas e adiciona "\n"
c_string_lines = ['String html =\n']
for line in html_content.splitlines():
    escaped_line = line.replace('\\', '\\\\').replace('"', '\\"')
    c_string_lines.append(f'"{escaped_line}\\n"\n')

# Finaliza com ponto e vírgula
c_string_lines[-1] = c_string_lines[-1].rstrip('\n') + ';\n'

# Salva em arquivo .c
with open("html_as_c_string.c", "w", encoding="utf-8") as file:
    file.writelines(c_string_lines)